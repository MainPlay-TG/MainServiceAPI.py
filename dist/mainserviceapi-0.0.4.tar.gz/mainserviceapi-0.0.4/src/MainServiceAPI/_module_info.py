name = "MainServiceAPI"
version = "0.0.4"
